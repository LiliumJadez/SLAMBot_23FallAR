
#include "TaskNav2.h"
using namespace floor_nav;

DYNAMIC_TASK(TaskFactoryNav2)
