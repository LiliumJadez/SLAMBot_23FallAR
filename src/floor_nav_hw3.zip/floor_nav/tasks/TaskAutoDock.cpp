
#include "TaskAutoDock.h"
using namespace floor_nav;

DYNAMIC_TASK(TaskFactoryAutoDock);
