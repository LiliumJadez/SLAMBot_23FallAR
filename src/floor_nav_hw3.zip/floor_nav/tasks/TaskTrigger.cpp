#include "TaskTrigger.h"
using namespace floor_nav;

DYNAMIC_TASK(TaskFactoryTrigger)
